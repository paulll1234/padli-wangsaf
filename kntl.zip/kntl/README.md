## RoF3X-Bot [MD]


## Install From Termux/Ubuntu/Ssh
```bash
apt update && apt upgrade
apt install git -y
apt install nodejs -y
apt install ffmpeg -y
pkg install yarn
git clone https://github.com/xiecaa/Wansap-Bot
cd Wansap-Bot
yarn
npm start
```

## Install From Windows/Rdp

Instal Git      : [`Klik Disini`](https://git-scm.com/downloads)
Instal NodeJS : [`Klik Disini`](https://nodejs.org/en/download)
Instal FFmpeg : [`Klik Disini`](https://ffmpeg.org/download.html)

```bash
git clone https://github.com/xiecaa/Wansap-Bot
cd Wansap-Bot
yarn
npm start
```

## Install From Heroku <BuildPack>

Install NodeJs : [`Klik Disini`](heroku/nodejs)
Install Ffmpeg : [`Klik Disini`](https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest.git)
Install Webp   : [`Klik Disini`](https://github.com/clhuang/heroku-buildpack-webp-binaries.git)

